export enum FormatoData {
    PADRAO = "DD/MM/AAAA",
    DIA_SEMANA_DIA_MES_ANO = "DIA_SEMANA, DD/MM/AAAA",
    DIA_MES = "DD/MM"
}
